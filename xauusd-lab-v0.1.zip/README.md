# XAUUSD Lab

Laboratoire de recherche et de paper trading XAUUSD. Sans IA et sans machine learning.

Objectif:
sources de données -> normalisation -> candidats open source -> backtest -> expérience 14h M/W/F -> paper trading IBKR -> éventuel live.

Default:
- XAUUSD
- 14:00 Pacific/Tahiti
- lundi, mercredi, vendredi
- timeframe 5m
- 1 trade maximum par jour d'expérience
- mode backtest
- live_orders_enabled=false

IMPORTANT:
Ce scaffold ne passe aucun ordre réel. Il faut valider le pipeline en backtest puis en Paper Trading avant toute architecture live.
