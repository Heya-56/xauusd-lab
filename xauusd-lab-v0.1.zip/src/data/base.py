from abc import ABC, abstractmethod
import pandas as pd

class MarketDataAdapter(ABC):
    name = "abstract"

    @abstractmethod
    def candles(self, symbol, timeframe, start=None, end=None) -> pd.DataFrame:
        raise NotImplementedError
